package dev.frost.calendar;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;

final class Alignment {
    static Bitmap extract(Bitmap image){
        int w=image.getWidth(),h=image.getHeight();
        int[] pixels=new int[w*h];image.getPixels(pixels,0,w,0,0,w,h);
        int[] colors={0xfffa13b1,0xff13eac9,0xffcde913,0xff5140fa};
        Rect[] marks=new Rect[4];
        for(int i=0;i<4;i++)marks[i]=marker(pixels,w,h,colors[i]);
        Rect area=new Rect(marks[0].left,marks[2].top,marks[1].right,marks[3].bottom);
        int tolerance=Math.max(4,marks[0].width());
        if(area.width()<4*tolerance||area.height()<4*tolerance||
           Math.abs(marks[2].centerX()-area.centerX())>tolerance||
           Math.abs(marks[3].centerX()-area.centerX())>tolerance||
           Math.abs(marks[0].centerY()-area.centerY())>tolerance||
           Math.abs(marks[1].centerY()-area.centerY())>tolerance)
            throw new IllegalArgumentException();
        // Continue nearby wallpaper over the four small markers, before blurring.
        for(int i=0;i<4;i++){
            Rect m=new Rect(marks[i]);m.inset(-2,-2);m.intersect(area);
            for(int y=m.top;y<m.bottom;y++)for(int x=m.left;x<m.right;x++){
                int sx=i==0?m.right:i==1?m.left-1:x;
                int sy=i==2?m.bottom:i==3?m.top-1:y;
                pixels[y*w+x]=pixels[sy*w+sx];
            }
        }
        return Bitmap.createBitmap(pixels,area.top*w+area.left,w,area.width(),area.height(),Bitmap.Config.ARGB_8888);
    }
    static Rect marker(int[] pixels,int w,int h,int color){
        Rect best=null;int longest=3;
        for(int y=0;y<h;y++){
            int x=0;
            while(x<w){
                if(!matches(pixels[y*w+x],color)){x++;continue;}
                int left=x++;while(x<w&&matches(pixels[y*w+x],color))x++;
                int width=x-left;
                if(width<=longest||width>w/8)continue;
                int mid=left+width/2,top=y,bottom=y+1;
                while(top>0&&matches(pixels[(top-1)*w+mid],color))top--;
                while(bottom<h&&matches(pixels[bottom*w+mid],color))bottom++;
                if(Math.abs(bottom-top-width)<=Math.max(2,width/5)){
                    longest=width;best=new Rect(left,top,x,bottom);
                }
            }
        }
        if(best==null)throw new IllegalArgumentException();
        return best;
    }
    static boolean matches(int a,int b){
        return Math.abs(Color.red(a)-Color.red(b))<=7&&Math.abs(Color.green(a)-Color.green(b))<=7&&Math.abs(Color.blue(a)-Color.blue(b))<=7;
    }
}
