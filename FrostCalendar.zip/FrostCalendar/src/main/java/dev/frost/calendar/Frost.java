package dev.frost.calendar;

import android.graphics.Bitmap;
import android.graphics.Color;

final class Frost {
    // Three separable box passes approximate a Gaussian with a radius relative to the crop.
    static Bitmap blur(Bitmap source,int strength){
        float scale=Math.min(1f,320f/Math.max(source.getWidth(),source.getHeight()));
        int w=Math.max(1,Math.round(source.getWidth()*scale)),h=Math.max(1,Math.round(source.getHeight()*scale));
        Bitmap scaled=Bitmap.createScaledBitmap(source,w,h,true);
        int[] pixels=new int[w*h],temp=new int[w*h];
        scaled.getPixels(pixels,0,w,0,0,w,h);
        int radius=Math.max(1,Math.round(Math.min(w,h)*strength/1000f));
        for(int pass=0;pass<3;pass++){
            smooth(pixels,temp,w,h,radius);smooth(temp,pixels,h,w,radius);
        }
        return Bitmap.createBitmap(pixels,w,h,Bitmap.Config.ARGB_8888);
    }
    static void smooth(int[] in,int[] out,int width,int height,int radius){
        int count=2*radius+1;
        for(int y=0;y<height;y++){
            int base=y*width,r=0,g=0,b=0;
            for(int x=-radius;x<=radius;x++){
                int c=in[base+Math.max(0,Math.min(width-1,x))];r+=Color.red(c);g+=Color.green(c);b+=Color.blue(c);
            }
            for(int x=0;x<width;x++){
                out[x*height+y]=Color.rgb(r/count,g/count,b/count);
                int drop=in[base+Math.max(0,x-radius)],add=in[base+Math.min(width-1,x+radius+1)];
                r+=Color.red(add)-Color.red(drop);g+=Color.green(add)-Color.green(drop);b+=Color.blue(add)-Color.blue(drop);
            }
        }
    }
}
