package dev.frost.calendar;

import android.appwidget.AppWidgetManager;
import android.content.*;
import android.os.Binder;
import android.provider.CalendarContract;
import android.widget.*;
import android.graphics.Typeface;
import java.time.LocalDate;
import java.util.*;

public class Agenda extends RemoteViewsService {
    static RemoteViews row(Context context,Widget.Entry e,int ink,Typeface font,int width){
        RemoteViews v=new RemoteViews(context.getPackageName(),R.layout.event);
        java.text.DateFormat clock=android.text.format.DateFormat.getTimeFormat(context);
        String time=e.allDay?"All day":clock.format(new Date(e.begin))+" – "+clock.format(new Date(e.end));
        Widget.label(context,v,"time",time,11,false,ink,font,width-30);
        Widget.label(context,v,"title",e.title,14,true,ink,font,width-30);
        float density=context.getResources().getDisplayMetrics().density;
        int barWidth=Math.max(2,Math.round(3*density)),barHeight=Math.max(2,Math.round(26*density));
        android.graphics.Bitmap bar=android.graphics.Bitmap.createBitmap(barWidth,barHeight,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        paint.setColor(e.color==0?Widget.BLUE:e.color);
        new android.graphics.Canvas(bar).drawRoundRect(0,0,barWidth,barHeight,barWidth/2f,barWidth/2f,paint);
        v.setImageViewBitmap(R.id.stripe,bar);
        v.setContentDescription(R.id.eventRow,e.title+", "+time);
        v.setOnClickFillInIntent(R.id.eventRow,new Intent().setData(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,e.id))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,e.begin).putExtra(CalendarContract.EXTRA_EVENT_END_TIME,e.end));
        return v;
    }
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent){
        int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);
        return new RemoteViewsFactory(){
            List<Widget.Entry> rows=Collections.emptyList();
            Typeface font; int width,ink;
            public void onCreate(){}
            public void onDataSetChanged(){
                long token=Binder.clearCallingIdentity();
                try{
                    font=Widget.imported(Agenda.this,id);width=Widget.width(Agenda.this,id);ink=Widget.textColor(Agenda.this,id);
                    rows=Widget.events(Agenda.this,Widget.prefs(Agenda.this,id).getStringSet("calendars",Collections.emptySet()),Widget.selected(Agenda.this,id,LocalDate.now()));
                }catch(RuntimeException e){rows=Collections.emptyList();}finally{Binder.restoreCallingIdentity(token);}
            }
            public int getCount(){return rows.size();}
            public RemoteViews getViewAt(int pos){
                if(pos<0||pos>=rows.size())return null;
                Widget.Entry e=rows.get(pos);
                return row(Agenda.this,e,ink,font,width);
            }
            public int getViewTypeCount(){return 1;}
            public boolean hasStableIds(){return false;}
            public long getItemId(int pos){return pos;}
            public RemoteViews getLoadingView(){return null;}
            public void onDestroy(){rows=Collections.emptyList();}
        };
    }
}
