package dev.frost.calendar;

import android.appwidget.AppWidgetManager;
import android.content.*;
import android.os.Binder;
import android.provider.CalendarContract;
import android.widget.*;
import android.graphics.Typeface;
import java.time.LocalDate;
import java.util.*;

public class Agenda extends RemoteViewsService {
    static RemoteViews row(Context context,Widget.Entry e,int ink,Typeface font,int width){
        RemoteViews v=new RemoteViews(context.getPackageName(),R.layout.event);
        java.text.DateFormat clock=android.text.format.DateFormat.getTimeFormat(context);
        String time=e.allDay?"All day":clock.format(new Date(e.begin))+" – "+clock.format(new Date(e.end));
        Widget.label(context,v,"time",time,11,false,ink,font,width-10);
        Widget.label(context,v,"title",e.title,14,true,ink,font,width-10);
        v.setInt(R.id.stripe,"setBackgroundColor",e.color==0?Widget.BLUE:e.color);
        v.setContentDescription(R.id.eventRow,e.title+", "+time);
        v.setOnClickFillInIntent(R.id.eventRow,new Intent().setData(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,e.id))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,e.begin).putExtra(CalendarContract.EXTRA_EVENT_END_TIME,e.end));
        return v;
    }
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent){
        int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);
        return new RemoteViewsFactory(){
            List<Widget.Entry> rows=Collections.emptyList();
            Typeface font; int width,ink;
            public void onCreate(){}
            public void onDataSetChanged(){
                long token=Binder.clearCallingIdentity();
                try{
                    font=Widget.imported(Agenda.this,id);width=Widget.width(Agenda.this,id);ink=Widget.textColor(Agenda.this,id);
                    rows=Widget.events(Agenda.this,Widget.prefs(Agenda.this,id).getStringSet("calendars",Collections.emptySet()),Widget.selected(Agenda.this,id,LocalDate.now()));
                }catch(RuntimeException e){rows=Collections.emptyList();}finally{Binder.restoreCallingIdentity(token);}
            }
            public int getCount(){return rows.size();}
            public RemoteViews getViewAt(int pos){
                if(pos<0||pos>=rows.size())return null;
                Widget.Entry e=rows.get(pos);
                return row(Agenda.this,e,ink,font,width);
            }
            public int getViewTypeCount(){return 1;}
            public boolean hasStableIds(){return false;}
            public long getItemId(int pos){return pos;}
            public RemoteViews getLoadingView(){return null;}
            public void onDestroy(){rows=Collections.emptyList();}
        };
    }
}
