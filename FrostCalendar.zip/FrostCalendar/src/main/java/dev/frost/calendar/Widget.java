package dev.frost.calendar;

import android.Manifest;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.*;
import android.text.TextUtils;
import android.widget.RemoteViews;
import java.io.File;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;

public class Widget extends AppWidgetProvider {
    static final int[] DAYS={R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6};
    static final int[] ROWS={R.id.e0,R.id.e1,R.id.e2};
    static final int INK=0xff182333, MUTED=0xff495562, BLUE=0xff177acf;
    static final String GOOGLE="com.google.android.calendar";
    static SharedPreferences prefs(Context c,int id){return c.getSharedPreferences("widget"+id,0);}
    static File file(Context c,int id,String name){return new File(c.getFilesDir(),id+"-"+name);}
    static final java.util.concurrent.ExecutorService worker=java.util.concurrent.Executors.newSingleThreadExecutor();
    @Override public void onReceive(Context c,Intent intent){
        String action=intent.getAction();
        if(Intent.ACTION_DATE_CHANGED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)||
           Intent.ACTION_TIMEZONE_CHANGED.equals(action)||Intent.ACTION_PROVIDER_CHANGED.equals(action)){
            onUpdate(c,AppWidgetManager.getInstance(c),AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,Widget.class)));
        }else super.onReceive(c,intent);
    }
    @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){
        PendingResult pending=goAsync();
        worker.execute(()->{try{for(int id:ids) render(c,id);}finally{if(pending!=null)pending.finish();}});
    }
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){onUpdate(c,m,new int[]{id});}
    @Override public void onDeleted(Context c,int[] ids){
        for(int id:ids){prefs(c,id).edit().clear().apply();file(c,id,"font").delete();file(c,id,"wall").delete();}
    }
    static class Tile {
        Bitmap bitmap; Canvas canvas; Paint pen=new Paint(3); Typeface face;
        Tile(int width,int height,Typeface type){
            bitmap=Bitmap.createBitmap(width*2,height*2,Bitmap.Config.ARGB_8888);
            canvas=new Canvas(bitmap);canvas.scale(2,2);face=type;
        }
        void text(String s,float x,float baseline,float size,int color,boolean bold,float max){
            pen.setTypeface(Typeface.create(face,bold?Typeface.BOLD:Typeface.NORMAL));pen.setTextSize(size);pen.setColor(color);
            if(pen.measureText(s)>max){
                int n=pen.breakText(s,true,Math.max(0,max-pen.measureText("…")),null);
                s=s.substring(0,n)+"…";
            }
            canvas.drawText(s,x,baseline,pen);
        }
        void pill(float x,float y,float w,float h,int color){
            pen.setColor(color);canvas.drawRoundRect(x,y,x+w,y+h,h/2,h/2,pen);
        }
    }
    static Intent dateIntent(long time){
        return new Intent(Intent.ACTION_VIEW,CalendarContract.CONTENT_URI.buildUpon().appendPath("time").appendPath(String.valueOf(time)).build()).setPackage(GOOGLE);
    }
    static void bind(Context c,RemoteViews v,int view,Tile tile,String desc,Intent action,int id){
        v.setImageViewBitmap(view,tile.bitmap);v.setContentDescription(view,desc);
        v.setOnClickPendingIntent(view,action==null?null:PendingIntent.getActivity(c,Objects.hash(id,view),action,
                PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT));
    }
    static class Entry {
        long id,begin,end; int color; String title; boolean allDay;
    }
    static List<Entry> events(Context c,Set<String> ids,LocalDate day){
        ZoneId zone=ZoneId.systemDefault();
        long start=day.atStartOfDay(zone).toInstant().toEpochMilli(),end=day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        long utc=day.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
        Uri.Builder uri=Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(uri,Math.min(start,utc));ContentUris.appendId(uri,Math.max(end,utc+86400000));
        List<Entry> list=new ArrayList<>();
        if(ids.isEmpty())return list;
        try(Cursor cur=c.getContentResolver().query(uri.build(),new String[]{Instances.EVENT_ID,Instances.BEGIN,Instances.END,
                Instances.TITLE,Instances.DISPLAY_COLOR,Instances.ALL_DAY,Instances.CALENDAR_ID,Instances.STATUS},null,null,"allDay DESC, begin ASC")){
            if(cur==null)throw new IllegalStateException("Calendar unavailable");
            while(cur.moveToNext()){
                if(!ids.contains(cur.getString(6))||cur.getInt(7)==Events.STATUS_CANCELED)continue;
                Entry e=new Entry();e.id=cur.getLong(0);e.begin=cur.getLong(1);e.end=cur.getLong(2);
                e.title=cur.isNull(3)?"Untitled event":cur.getString(3);e.color=cur.getInt(4);e.allDay=cur.getInt(5)!=0;
                long lo=e.allDay?utc:start,hi=e.allDay?utc+86400000:end;
                if(e.begin>=hi||(e.end==e.begin?e.begin<lo:e.end<=lo))continue;
                list.add(e);
            }
        }
        return list;
    }
    static void render(Context c,int id){
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
        SharedPreferences p=prefs(c,id); AppWidgetManager manager=AppWidgetManager.getInstance(c);
        Bundle options=manager.getAppWidgetOptions(id);
        int w=Math.max(142,Math.min(480,options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,196)-18));
        Typeface font=Typeface.create("google-sans",Typeface.NORMAL);
        if(file(c,id,"font").isFile())try{font=Typeface.createFromFile(file(c,id,"font"));}catch(RuntimeException ignored){}
        if(file(c,id,"wall").isFile()){
            Bitmap bg=BitmapFactory.decodeFile(file(c,id,"wall").getPath());
            if(bg!=null)v.setImageViewBitmap(R.id.wall,bg);
        }
        Locale loc=Locale.getDefault();LocalDate today=LocalDate.now();ZoneId zone=ZoneId.systemDefault();
        LocalDate monday=today.minusDays(today.getDayOfWeek().getValue()-1);
        long now=System.currentTimeMillis();
        int hw=w*4/5;
        Tile head=new Tile(hw,45,font);
        String day=String.valueOf(today.getDayOfMonth());
        head.text(day,1,34,32,INK,true,50);
        float x=head.pen.measureText(day)+6;
        head.text(today.getMonth().getDisplayName(TextStyle.FULL,loc),x,18,14,INK,true,hw-x);
        head.text("Today, "+today.getDayOfWeek().getDisplayName(TextStyle.FULL,loc),x,33,11,MUTED,false,hw-x);
        bind(c,v,R.id.header,head,today.toString(),dateIntent(now),id);
        int pw=w-hw;Tile plus=new Tile(pw,45,font);plus.pill(pw/2f-13,11,26,20,0x669daab7);
        plus.pen.setColor(INK);plus.pen.setStrokeWidth(1.5f);
        plus.canvas.drawLine(pw/2f-5,21,pw/2f+5,21,plus.pen);plus.canvas.drawLine(pw/2f,16,pw/2f,26,plus.pen);
        Intent add=new Intent(Intent.ACTION_INSERT,Events.CONTENT_URI).setPackage(GOOGLE).putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,now);
        bind(c,v,R.id.plus,plus,"Create event",add,id);
        for(int i=0;i<7;i++){
            LocalDate d=monday.plusDays(i);int dw=w/7;Tile t=new Tile(dw,38,font);
            String label=d.getDayOfWeek().getDisplayName(TextStyle.SHORT,loc).toUpperCase(loc);
            t.pen.setTextAlign(Paint.Align.CENTER);
            t.text(label,dw/2f,11,9,MUTED,true,dw);
            if(d.equals(today))t.pill(1,15,dw-2,20,BLUE);
            t.text(""+d.getDayOfMonth(),dw/2f,30,13,d.equals(today)?-1:INK,false,dw);
            bind(c,v,DAYS[i],t,d.toString(),dateIntent(d.atTime(12,0).atZone(zone).toInstant().toEpochMilli()),id);
        }
        Set<String> ids=p.getStringSet("calendars",Collections.emptySet());
        List<Entry> list=Collections.emptyList(); String empty="No events today";
        Intent emptyAction=dateIntent(now);
        if(ids.isEmpty()||c.checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED){
            empty="Choose calendars"; emptyAction=new Intent(c,Setup.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
        }else try{list=events(c,ids,today);}catch(RuntimeException error){empty="Calendar unavailable";}
        java.text.DateFormat clock=android.text.format.DateFormat.getTimeFormat(c);
        // Favor remaining appointments when today's agenda exceeds the three visible slots.
        if(list.size()>3 && list.stream().anyMatch(e->e.allDay||e.end>now))list.removeIf(e->!e.allDay && e.end<=now);
        for(int i=0;i<3;i++){
            Tile t=new Tile(w,35,font);String desc="";Intent tap=null;
            if(i<list.size()){
                Entry e=list.get(i);
                String time=e.allDay?"All day":clock.format(new Date(e.begin))+" – "+clock.format(new Date(e.end));
                t.pill(1,5,3,25,e.color==0?BLUE:e.color);
                t.text(time,10,14,10,MUTED,false,w-10);t.text(e.title,10,29,13,INK,true,w-10);
                tap=new Intent(Intent.ACTION_VIEW,ContentUris.withAppendedId(Events.CONTENT_URI,e.id)).setPackage(GOOGLE)
                   .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,e.begin).putExtra(CalendarContract.EXTRA_EVENT_END_TIME,e.end);
                desc=e.title+", "+time;
            }else if(i==0){
                desc=empty;t.text(empty,2,22,13,MUTED,false,w-4);tap=emptyAction;
            }
            bind(c,v,ROWS[i],t,desc,tap,id);
        }
        manager.updateAppWidget(id,v);
    }
}
