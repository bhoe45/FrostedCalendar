package dev.frost.calendar;

import android.Manifest;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.*;
import android.text.TextUtils;
import android.widget.RemoteViews;
import java.io.File;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;

public class Widget extends AppWidgetProvider {
    static final int[] DAYS={R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6};
    static final int INK=0xff182333, MUTED=0xff495562, BLUE=0xff177acf;
    static final String GOOGLE="com.google.android.calendar";
    static SharedPreferences prefs(Context c,int id){return c.getSharedPreferences("widget"+id,0);}
    static File file(Context c,int id,String name){return new File(c.getFilesDir(),id+"-"+name);}
    static final java.util.concurrent.ExecutorService worker=java.util.concurrent.Executors.newSingleThreadExecutor();
    @Override public void onReceive(Context c,Intent intent){
        String action=intent.getAction();
        if(Intent.ACTION_DATE_CHANGED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)||
           Intent.ACTION_TIMEZONE_CHANGED.equals(action)||Intent.ACTION_PROVIDER_CHANGED.equals(action)){
            onUpdate(c,AppWidgetManager.getInstance(c),AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,Widget.class)));
        }else super.onReceive(c,intent);
    }
    @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){
        PendingResult pending=goAsync();
        worker.execute(()->{try{for(int id:ids) render(c,id);}finally{if(pending!=null)pending.finish();}});
    }
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){onUpdate(c,m,new int[]{id});}
    @Override public void onDeleted(Context c,int[] ids){
        for(int id:ids){prefs(c,id).edit().clear().apply();file(c,id,"font").delete();file(c,id,"wall").delete();file(c,id,"crop").delete();file(c,id,"blurred").delete();}
    }
    static Intent dateIntent(long time){
        return new Intent(Intent.ACTION_VIEW,CalendarContract.CONTENT_URI.buildUpon().appendPath("time").appendPath(String.valueOf(time)).build()).setPackage(GOOGLE);
    }
    static class Entry {
        long id,begin,end; int color; String title; boolean allDay;
    }
    static List<Entry> events(Context c,Set<String> ids,LocalDate day){
        ZoneId zone=ZoneId.systemDefault();
        long start=day.atStartOfDay(zone).toInstant().toEpochMilli(),end=day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        long utc=day.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
        Uri.Builder uri=Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(uri,Math.min(start,utc));ContentUris.appendId(uri,Math.max(end,utc+86400000));
        List<Entry> list=new ArrayList<>();
        if(ids.isEmpty())return list;
        try(Cursor cur=c.getContentResolver().query(uri.build(),new String[]{Instances.EVENT_ID,Instances.BEGIN,Instances.END,
                Instances.TITLE,Instances.DISPLAY_COLOR,Instances.ALL_DAY,Instances.CALENDAR_ID,Instances.STATUS},null,null,"allDay DESC, begin ASC")){
            if(cur==null)throw new IllegalStateException("Calendar unavailable");
            while(cur.moveToNext()){
                if(!ids.contains(cur.getString(6))||cur.getInt(7)==Events.STATUS_CANCELED)continue;
                Entry e=new Entry();e.id=cur.getLong(0);e.begin=cur.getLong(1);e.end=cur.getLong(2);
                e.title=cur.isNull(3)?"Untitled event":cur.getString(3);e.color=cur.getInt(4);e.allDay=cur.getInt(5)!=0;
                long lo=e.allDay?utc:start,hi=e.allDay?utc+86400000:end;
                if(e.begin>=hi||(e.end==e.begin?e.begin<lo:e.end<=lo))continue;
                list.add(e);
            }
        }
        return list;
    }
    static Typeface imported(Context c,int id){
        File f=file(c,id,"font");
        if(f.exists())try{return Typeface.createFromFile(f);}catch(RuntimeException ignored){}
        return null;
    }
    static int resource(Context c,String name){return c.getResources().getIdentifier(name,"id",c.getPackageName());}
    static void label(Context c,RemoteViews views,String name,String value,int sp,boolean bold,int color,Typeface font,int maxDp){
        int text=resource(c,name),image=resource(c,name+"Ink");
        views.setTextViewText(text,value);views.setTextColor(text,color);
        views.setViewVisibility(text,font==null?0:8);views.setViewVisibility(image,font==null?8:0);
        if(font==null)return;
        android.util.DisplayMetrics metrics=c.getResources().getDisplayMetrics();
        android.text.TextPaint paint=new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
        paint.setTypeface(Typeface.create(font,bold?Typeface.BOLD:Typeface.NORMAL));
        paint.setTextSize(android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP,sp,metrics));
        paint.setColor(color);
        String shown=TextUtils.ellipsize(value,paint,Math.max(1,maxDp*metrics.density-4),TextUtils.TruncateAt.END).toString();
        Paint.FontMetricsInt fm=paint.getFontMetricsInt();
        Bitmap bmp=Bitmap.createBitmap(Math.max(1,(int)Math.ceil(paint.measureText(shown))+4),fm.bottom-fm.top+2,Bitmap.Config.ARGB_8888);
        bmp.setDensity(metrics.densityDpi);
        new Canvas(bmp).drawText(shown,2,1-fm.top,paint);
        views.setImageViewBitmap(image,bmp);
    }
    static int width(Context c,int id){
        Bundle opts=AppWidgetManager.getInstance(c).getAppWidgetOptions(id);
        boolean landscape=c.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        return Math.max(130,opts.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH:AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,196)-20);
    }
    static void click(Context c,RemoteViews v,int view,int id,Intent action,String desc){
        v.setContentDescription(view,desc);
        v.setOnClickPendingIntent(view,PendingIntent.getActivity(c,Objects.hash(id,view),action,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
    }
    static void render(Context c,int id){
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
        SharedPreferences p=prefs(c,id);
        int strength=p.getInt("blur",45);
        Bitmap bg=strength==0?null:BitmapFactory.decodeFile(file(c,id,"blurred").getPath());
        v.setImageViewBitmap(R.id.wall,bg);
        int ink=textColor(c,id);
        Typeface font=imported(c,id);int w=width(c,id);
        Locale loc=Locale.getDefault();LocalDate today=LocalDate.now();
        LocalDate monday=today.minusDays(today.getDayOfWeek().getValue()-1);
        long now=System.currentTimeMillis();
        label(c,v,"dateNum",""+today.getDayOfMonth(),30,true,ink,font,54);
        label(c,v,"month",today.getMonth().getDisplayName(TextStyle.FULL,loc),14,true,ink,font,w-73);
        label(c,v,"today","Today, "+today.getDayOfWeek().getDisplayName(TextStyle.FULL,loc),11,false,ink,font,w-73);
        click(c,v,R.id.header,id,dateIntent(now),today.toString());
        v.setTextColor(R.id.plus,ink);
        click(c,v,R.id.plus,id,new Intent(Intent.ACTION_INSERT,Events.CONTENT_URI).setPackage(GOOGLE).putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,now),"Create event");
        for(int i=0;i<7;i++){
            LocalDate d=monday.plusDays(i);boolean active=d.equals(today);
            label(c,v,"weekday"+i,d.getDayOfWeek().getDisplayName(TextStyle.SHORT,loc).toUpperCase(loc),9,false,ink,font,w/7);
            label(c,v,"num"+i,""+d.getDayOfMonth(),14,true,active?Color.WHITE:ink,font,w/7-4);
            v.setInt(resource(c,"bubble"+i),"setBackgroundResource",active?R.drawable.selected:0);
            click(c,v,DAYS[i],id,dateIntent(d.atTime(12,0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()),d.toString());
        }
        boolean configure=p.getStringSet("calendars",Collections.emptySet()).isEmpty()||c.checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED;
        String empty=configure?"Choose calendars":"No events today";
        v.setTextViewText(R.id.empty,empty);v.setTextColor(R.id.empty,ink);
        click(c,v,R.id.empty,id,configure?new Intent(c,Setup.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id):dateIntent(now),empty);
        Intent adapter=new Intent(c,Agenda.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).setData(Uri.parse("frost://agenda/"+id));
        v.setRemoteAdapter(R.id.agenda,adapter);v.setEmptyView(R.id.agenda,R.id.empty);
        Intent open=new Intent(Intent.ACTION_VIEW).setPackage(GOOGLE);
        v.setPendingIntentTemplate(R.id.agenda,PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT));
        AppWidgetManager m=AppWidgetManager.getInstance(c);m.updateAppWidget(id,v);
        m.notifyAppWidgetViewDataChanged(id,R.id.agenda);
    }
    static int textColor(Context c,int id){
        SharedPreferences p=prefs(c,id);
        if(p.getInt("blur",45)>0 && file(c,id,"blurred").exists())return p.getInt("textColor",Color.WHITE);
        android.app.WallpaperColors palette=android.app.WallpaperManager.getInstance(c).getWallpaperColors(android.app.WallpaperManager.FLAG_SYSTEM);
        return palette!=null&&(palette.getColorHints()&android.app.WallpaperColors.HINT_SUPPORTS_DARK_TEXT)!=0?INK:Color.WHITE;
    }
}
