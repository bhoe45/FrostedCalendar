package dev.frost.calendar;

import android.Manifest;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.*;
import android.text.TextUtils;
import android.widget.RemoteViews;
import java.io.File;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;

public class Widget extends AppWidgetProvider {
    static final int[] DAYS={R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6};
    static final int INK=0xff182333, MUTED=0xff495562, BLUE=0xff177acf;
    static final String GOOGLE="com.google.android.calendar";
    static SharedPreferences prefs(Context c,int id){return c.getSharedPreferences("widget"+id,0);}
    static File file(Context c,int id,String name){return new File(c.getFilesDir(),id+"-"+name);}
    static final java.util.concurrent.ExecutorService worker=java.util.concurrent.Executors.newSingleThreadExecutor();
    @Override public void onReceive(Context c,Intent intent){
        String action=intent.getAction();
        if("dev.frost.calendar.SELECT_DAY".equals(action)){
            int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);
            if(id<1||AppWidgetManager.getInstance(c).getAppWidgetInfo(id)==null)return;
            long day=intent.getLongExtra("day",Long.MIN_VALUE);
            LocalDate today=LocalDate.now();
            long first=today.toEpochDay();
            if(day<first||day>=first+7)return;
            prefs(c,id).edit().putLong("day",day).putLong("pickedOn",today.toEpochDay()).putLong("resetAt",day==first?0:android.os.SystemClock.elapsedRealtime()+120000).apply();
            PendingResult pending=goAsync();
            worker.execute(()->{
                try{
                    if(selected(c,id,LocalDate.now()).toEpochDay()==day)render(c,id,true);
                }finally{if(pending!=null)pending.finish();}
            });
            return;
        }
        if("dev.frost.calendar.REFRESH".equals(action)){
            int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);
            if(id>0&&AppWidgetManager.getInstance(c).getAppWidgetInfo(id)!=null){
                PendingResult pending=goAsync();
                worker.execute(()->{try{render(c,id,true);}finally{if(pending!=null)pending.finish();}});
            }
            return;
        }
        if(Intent.ACTION_BOOT_COMPLETED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)){
            int[] ids=AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,Widget.class));
            for(int id:ids)prefs(c,id).edit().remove("resetAt").remove("pickedOn").apply();
        }
        if(Intent.ACTION_BOOT_COMPLETED.equals(action)||Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)||Intent.ACTION_DATE_CHANGED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)||
           Intent.ACTION_TIMEZONE_CHANGED.equals(action)||Intent.ACTION_PROVIDER_CHANGED.equals(action)){
            onUpdate(c,AppWidgetManager.getInstance(c),AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,Widget.class)));
        }else super.onReceive(c,intent);
    }
    @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){
        PendingResult pending=goAsync();
        worker.execute(()->{try{for(int id:ids) render(c,id);}finally{if(pending!=null)pending.finish();}});
    }
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){
        // Apply compact spacing and font measurements after the drag settles.
        if(prefs(c,id).getBoolean("aligning",false))return;
        final PendingResult pending=goAsync();
        final int revision;
        synchronized(resizeRevisions){revision=resizeRevisions.get(id,0)+1;resizeRevisions.put(id,revision);}
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->worker.execute(()->{
            try{
                synchronized(resizeRevisions){if(resizeRevisions.get(id)!=revision)return;resizeRevisions.delete(id);}
                if(m.getAppWidgetInfo(id)!=null)render(c,id);
            }finally{if(pending!=null)pending.finish();}
        }),250);
    }
    private static final android.util.SparseIntArray resizeRevisions=new android.util.SparseIntArray();
    @Override public void onDeleted(Context c,int[] ids){
        for(int id:ids){c.getSystemService(AlarmManager.class).cancel(refreshIntent(c,id));prefs(c,id).edit().clear().apply();file(c,id,"font").delete();file(c,id,"wall").delete();file(c,id,"crop").delete();file(c,id,"blurred").delete();}
    }
    static Intent dateIntent(long time){
        return new Intent(Intent.ACTION_VIEW,CalendarContract.CONTENT_URI.buildUpon().appendPath("time").appendPath(String.valueOf(time)).build()).setPackage(GOOGLE);
    }
    static class Entry {
        long id,begin,end; int color; String title; boolean allDay;
    }
    static List<Entry> events(Context c,Set<String> ids,LocalDate day){
        ZoneId zone=ZoneId.systemDefault();
        long start=day.atStartOfDay(zone).toInstant().toEpochMilli(),end=day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        long utc=day.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
        Uri.Builder uri=Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(uri,Math.min(start,utc));ContentUris.appendId(uri,Math.max(end,utc+86400000));
        List<Entry> list=new ArrayList<>();
        if(ids.isEmpty())return list;
        try(Cursor cur=c.getContentResolver().query(uri.build(),new String[]{Instances.EVENT_ID,Instances.BEGIN,Instances.END,
                Instances.TITLE,Instances.DISPLAY_COLOR,Instances.ALL_DAY,Instances.CALENDAR_ID,Instances.STATUS},null,null,"allDay DESC, begin ASC")){
            if(cur==null)throw new IllegalStateException("Calendar unavailable");
            while(cur.moveToNext()){
                if(!ids.contains(cur.getString(6))||cur.getInt(7)==Events.STATUS_CANCELED)continue;
                Entry e=new Entry();e.id=cur.getLong(0);e.begin=cur.getLong(1);e.end=cur.getLong(2);
                e.title=cur.isNull(3)?"Untitled event":cur.getString(3);e.color=cur.getInt(4);e.allDay=cur.getInt(5)!=0;
                long lo=e.allDay?utc:start,hi=e.allDay?utc+86400000:end;
                if(e.begin>=hi||(e.end==e.begin?e.begin<lo:e.end<=lo))continue;
                list.add(e);
            }
        }
        return list;
    }
    static Typeface imported(Context c,int id){
        File f=file(c,id,"font");
        if(f.exists())try{return Typeface.createFromFile(f);}catch(RuntimeException ignored){}
        return null;
    }
    static int resource(Context c,String name){return c.getResources().getIdentifier(name,"id",c.getPackageName());}
    static void label(Context c,RemoteViews views,String name,String value,int sp,boolean bold,int color,Typeface font,int maxDp){
        int text=resource(c,name),image=resource(c,name+"Ink");
        views.setTextViewText(text,value);views.setTextColor(text,color);
        views.setViewVisibility(text,font==null?0:8);views.setViewVisibility(image,font==null?8:0);
        if(font==null)return;
        android.util.DisplayMetrics metrics=c.getResources().getDisplayMetrics();
        android.text.TextPaint paint=new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
        paint.setTypeface(Typeface.create(font,bold?Typeface.BOLD:Typeface.NORMAL));
        paint.setTextSize(android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP,sp,metrics));
        paint.setColor(color);
        String shown=TextUtils.ellipsize(value,paint,Math.max(1,maxDp*metrics.density-4),TextUtils.TruncateAt.END).toString();
        Paint.FontMetricsInt fm=paint.getFontMetricsInt();
        Bitmap bmp=Bitmap.createBitmap(Math.max(1,(int)Math.ceil(paint.measureText(shown))+4),fm.bottom-fm.top+2,Bitmap.Config.ARGB_8888);
        bmp.setDensity(metrics.densityDpi);
        new Canvas(bmp).drawText(shown,2,1-fm.top,paint);
        views.setImageViewBitmap(image,bmp);
    }
    static int width(Context c,int id){
        Bundle opts=AppWidgetManager.getInstance(c).getAppWidgetOptions(id);
        boolean landscape=c.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        return Math.max(130,opts.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH:AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,196)-20);
    }
    static void click(Context c,RemoteViews v,int view,int id,Intent action,String desc){
        v.setContentDescription(view,desc);
        v.setOnClickPendingIntent(view,PendingIntent.getActivity(c,Objects.hash(id,view),action,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
    }
    static LocalDate selected(Context c,int id,LocalDate today){
        SharedPreferences p=prefs(c,id);
        long day=p.getLong("day",today.toEpochDay()),now=android.os.SystemClock.elapsedRealtime(),reset=p.getLong("resetAt",0);
        if(p.getLong("pickedOn",Long.MIN_VALUE)!=today.toEpochDay()||reset<=now||reset-now>120000||
            day<today.toEpochDay()||day>=today.plusDays(7).toEpochDay())return today;
        return LocalDate.ofEpochDay(day);
    }
    static void render(Context c,int id){render(c,id,false);}
    static synchronized void render(Context c,int id,boolean dayTap){
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
        SharedPreferences p=prefs(c,id);
        if(p.getBoolean("aligning",false)){
            RemoteViews markers=new RemoteViews(c.getPackageName(),R.layout.align);
            click(c,markers,R.id.align,id,new Intent(c,Setup.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id),"Import alignment screenshot");
            AppWidgetManager.getInstance(c).updateAppWidget(id,markers);return;
        }
        int strength=p.getInt("blur",45);
        Bitmap bg=strength==0?null:BitmapFactory.decodeFile(file(c,id,"blurred").getPath());
        if(bg==null&&strength>0&&file(c,id,"crop").isFile()){
            Bitmap source=BitmapFactory.decodeFile(file(c,id,"crop").getPath());
            if(source!=null)bg=Frost.blur(source,strength);
        }
        v.setImageViewBitmap(R.id.wall,bg);
        Bundle options=AppWidgetManager.getInstance(c).getAppWidgetOptions(id);
        boolean landscape=c.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        int height=options.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT:AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,165);
        boolean compact=height<145;
        float density=c.getResources().getDisplayMetrics().density;
        v.setViewPadding(R.id.content,Math.round(10*density),Math.round((compact?4:8)*density),
            Math.round(10*density),Math.round((compact?3:7)*density));

        int ink=textColor(c,id);
        Typeface font=imported(c,id);int w=width(c,id);int weekWidth=w-24;
        Locale loc=Locale.getDefault();LocalDate today=LocalDate.now();
        LocalDate first=today;
        LocalDate day=selected(c,id,today);
        boolean isToday=day.equals(today);
        long now=isToday?System.currentTimeMillis():day.atTime(12,0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        long previous=p.getLong("shownDay",day.toEpochDay());
        boolean moving=dayTap && previous!=day.toEpochDay() &&
            previous>=first.toEpochDay() && previous<first.plusDays(7).toEpochDay() &&
            android.animation.ValueAnimator.areAnimatorsEnabled();
        int delta=moving?(int)(day.toEpochDay()-previous):0;
        int trackLayout=delta==0?R.layout.marker_track:c.getResources().getIdentifier(
            "travel_"+(delta<0?"l":"r")+Math.abs(delta),"layout",c.getPackageName());
        RemoteViews track=new RemoteViews(c.getPackageName(),trackLayout);
        track.setViewVisibility(resource(c,"mark"+(day.toEpochDay()-today.toEpochDay())),android.view.View.VISIBLE);
        v.removeAllViews(R.id.track);v.addView(R.id.track,track);
        v.removeAllViews(R.id.panel);
        v.addStableView(R.id.panel,new RemoteViews(c.getPackageName(),moving?R.layout.agenda_enter:R.layout.agenda_panel),(int)day.toEpochDay());
        v.setTextColor(R.id.plus,ink);
        click(c,v,R.id.plus,id,new Intent(Intent.ACTION_INSERT,Events.CONTENT_URI).setPackage(GOOGLE).putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,now),"Create event");
        for(int i=0;i<7;i++){
            LocalDate d=first.plusDays(i);boolean active=d.equals(day);
            label(c,v,"weekday"+i,d.getDayOfWeek().getDisplayName(TextStyle.SHORT,loc).toUpperCase(loc),9,false,ink,font,weekWidth/7);
            label(c,v,"num"+i,""+d.getDayOfMonth(),14,true,active?Color.WHITE:ink,font,weekWidth/7-4);
            Intent pick=new Intent(c,Widget.class).setAction("dev.frost.calendar.SELECT_DAY")
                .setData(Uri.parse("frost://day/"+id+"/"+d.toEpochDay()))
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).putExtra("day",d.toEpochDay());
            v.setContentDescription(DAYS[i],d.toString()+(active?", selected":""));
            v.setOnClickPendingIntent(DAYS[i],PendingIntent.getBroadcast(c,0,pick,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
        }
        boolean configure=p.getStringSet("calendars",Collections.emptySet()).isEmpty()||c.checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED;
        String empty=configure?"Choose calendars":(isToday?"No events today":"No events on "+day.getDayOfWeek().getDisplayName(TextStyle.FULL,loc));
        v.setTextViewText(R.id.empty,empty);v.setTextColor(R.id.empty,ink);
        click(c,v,R.id.empty,id,configure?new Intent(c,Setup.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id):dateIntent(now),empty);
        List<Entry> entries=Collections.emptyList();
        if(!configure){
            try{entries=events(c,p.getStringSet("calendars",Collections.emptySet()),day);}
            catch(RuntimeException e){v.setTextViewText(R.id.empty,"Calendar unavailable");}
        }
        // Large lists with an imported bitmap font are served lazily to bound IPC memory.
        boolean lazy=entries.size()>80 || (font!=null && entries.size()>4);
        if(lazy){
            Intent adapter=new Intent(c,Agenda.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id)
                .setData(Uri.parse("frost://agenda/"+id));
            v.setRemoteAdapter(R.id.agenda,adapter);
        }else{
            RemoteViews.RemoteCollectionItems.Builder items=new RemoteViews.RemoteCollectionItems.Builder().setViewTypeCount(1);
            for(int i=0;i<entries.size();i++){
                items.addItem(i,Agenda.row(c,entries.get(i),ink,font,w));
            }
            v.setRemoteAdapter(R.id.agenda,items.build());
        }
        v.setEmptyView(R.id.agenda,R.id.empty);
        Intent open=new Intent(Intent.ACTION_VIEW).setPackage(GOOGLE);
        v.setPendingIntentTemplate(R.id.agenda,PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT));
        if(!day.equals(selected(c,id,LocalDate.now())))return;
        AppWidgetManager m=AppWidgetManager.getInstance(c);m.updateAppWidget(id,v);
        p.edit().putLong("shownDay",day.toEpochDay()).apply();
        if(lazy)m.notifyAppWidgetViewDataChanged(id,R.id.agenda);
        scheduleRefresh(c,id,today,day);
    }
    static PendingIntent refreshIntent(Context c,int id){
        Intent intent=new Intent(c,Widget.class).setAction("dev.frost.calendar.REFRESH")
            .setData(Uri.parse("frost://refresh/"+id)).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
        return PendingIntent.getBroadcast(c,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static void scheduleRefresh(Context c,int id,LocalDate today,LocalDate selected){
        AlarmManager alarms=c.getSystemService(AlarmManager.class);
        long elapsed=android.os.SystemClock.elapsedRealtime();
        long midnight=today.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        long when=elapsed+Math.max(1,midnight-System.currentTimeMillis());
        if(!selected.equals(today))when=Math.min(when,prefs(c,id).getLong("resetAt",when));
        PendingIntent intent=refreshIntent(c,id);
        if(alarms.canScheduleExactAlarms())alarms.setExact(AlarmManager.ELAPSED_REALTIME,Math.max(elapsed+1,when),intent);
        else alarms.set(AlarmManager.ELAPSED_REALTIME,Math.max(elapsed+1,when),intent);
    }
    static int textColor(Context c,int id){
        SharedPreferences p=prefs(c,id);
        if(p.getInt("blur",45)>0 && file(c,id,"blurred").exists())return p.getInt("textColor",Color.WHITE);
        android.app.WallpaperColors palette=android.app.WallpaperManager.getInstance(c).getWallpaperColors(android.app.WallpaperManager.FLAG_SYSTEM);
        return palette!=null&&(palette.getColorHints()&android.app.WallpaperColors.HINT_SUPPORTS_DARK_TEXT)!=0?INK:Color.WHITE;
    }
}
