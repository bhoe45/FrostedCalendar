package dev.frost.calendar;

import android.Manifest;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract.Calendars;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class Setup extends Activity {
    int id; LinearLayout page, calendars; SharedPreferences prefs;
    final Map<String,CheckBox> choices=new LinkedHashMap<>();
    final Set<String> picked=new HashSet<>();
    File temporaryFont,temporaryWall;
    SeekBar blur; TextView amount; ImageView preview; Bitmap previewCrop;
    String draft; boolean initialized; Button save;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);setResult(RESULT_CANCELED);
        id=getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);
        if(id<1||AppWidgetManager.getInstance(this).getAppWidgetInfo(id)==null){finish();return;}
        prefs=Widget.prefs(this,id);
        draft=state==null?UUID.randomUUID().toString():state.getString("draft");
        temporaryFont=new File(getCacheDir(),draft+".font");temporaryWall=new File(getCacheDir(),draft+".wall");
        if(state!=null){picked.addAll(state.getStringArrayList("picked"));initialized=state.getBoolean("initialized");}
        ScrollView scroll=new ScrollView(this);page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(22),dp(36),dp(22),dp(32));scroll.addView(page);setContentView(scroll);
        label("Frost Calendar",29);label("Calendars on this widget",19);
        calendars=new LinearLayout(this);calendars.setOrientation(1);page.addView(calendars);
        label("Wallpaper blur",19);label("Choose your wallpaper image, then tap the area beneath the widget.",14);
        button(page,"Choose wallpaper",()->pick("image/*",2));
        amount=new TextView(this);page.addView(amount);
        blur=new SeekBar(this);blur.setContentDescription("Wallpaper blur strength");blur.setMax(100);
        blur.setProgress(state==null?prefs.getInt("blur",45):state.getInt("blur"));page.addView(blur);
        preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.CENTER_CROP);page.addView(preview,-1,dp(82));
        loadPreview();
        blur.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
            public void onProgressChanged(SeekBar s,int value,boolean user){updatePreview();}
        });
        label("Typeface",19);label("Choose a Product Sans TTF or OTF file to use it throughout the widget.",14);
        button(page,"Choose font file",()->pick("*/*",3));
        save=button(page,"Save widget",this::commit);loadCalendars();
    }
    void loadPreview(){
        File crop=temporaryWall.isFile()?temporaryWall:Widget.file(this,id,"crop");
        previewCrop=crop.isFile()?BitmapFactory.decodeFile(crop.getPath()):null;
        preview.setImageBitmap(previewCrop);updatePreview();
    }
    void updatePreview(){
        int value=blur.getProgress();
        amount.setText(value==0?"0% · Transparent":value+"% blur"+(previewCrop==null?" · Choose a wallpaper image":""));
        preview.setVisibility(previewCrop==null?View.GONE:View.VISIBLE);
        float radius=Math.max(0.1f,dp(14)*value/100f);
        preview.setRenderEffect(value==0?null:RenderEffect.createBlurEffect(radius,radius,Shader.TileMode.CLAMP));
    }
    int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    void label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(0,dp(9),0,dp(4));page.addView(t);}
    Button button(LinearLayout parent,String s,Runnable run){Button b=new Button(this);b.setText(s);b.setAllCaps(false);parent.addView(b);b.setOnClickListener(v->run.run());return b;}
    void loadCalendars(){
        calendars.removeAllViews();choices.clear();save.setEnabled(false);
        if(checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED){
            button(calendars,"Allow calendar access",()->requestPermissions(new String[]{Manifest.permission.READ_CALENDAR},1));return;
        }
        try(Cursor r=getContentResolver().query(Calendars.CONTENT_URI,new String[]{Calendars._ID,Calendars.CALENDAR_DISPLAY_NAME,Calendars.ACCOUNT_NAME,Calendars.VISIBLE},
                Calendars.ACCOUNT_TYPE+"=?",new String[]{"com.google"},"account_name,calendar_displayName")){
            Set<String> saved=prefs.getStringSet("calendars",null);
            if(r!=null)while(r.moveToNext()){
                String key=r.getString(0);CheckBox b=new CheckBox(this);b.setText(r.getString(1)+"\n"+r.getString(2));
                b.setChecked(initialized?picked.contains(key):saved==null?r.getInt(3)!=0:saved.contains(key));
                calendars.addView(b);choices.put(key,b);
            }
        }catch(RuntimeException e){notice("Could not read calendars. Check calendar access and try again.");return;}
        if(choices.isEmpty()){
            TextView msg=new TextView(this);msg.setText("Enable sync for your Google calendars on this phone, then refresh.");calendars.addView(msg);
            button(calendars,"Refresh list",this::loadCalendars);
        }
        save.setEnabled(true);
    }
    void notice(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    Set<String> selection(){Set<String> result=new HashSet<>();choices.forEach((k,b)->{if(b.isChecked())result.add(k);});return result;}
    @Override public void onSaveInstanceState(Bundle b){
        super.onSaveInstanceState(b);b.putInt("blur",blur.getProgress());b.putString("draft",draft);b.putStringArrayList("picked",new ArrayList<>(selection()));b.putBoolean("initialized",!choices.isEmpty());
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
        super.onRequestPermissionsResult(request,permissions,results);loadCalendars();
        if(results.length>0&&results[0]!=PackageManager.PERMISSION_GRANTED)notice("Calendar access is needed. You can also allow it in Android app settings.");
    }
    void pick(String type,int code){startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(type),code);}
    @Override public void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{
            if(request==2){
                Bitmap bitmap=ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(),uri),(decoder,info,source)->{
                    int longest=Math.max(info.getSize().getWidth(),info.getSize().getHeight());
                    decoder.setTargetSampleSize(Math.max(1,(longest+1199)/1200));decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                });
                Crop crop=new Crop(bitmap);
                new AlertDialog.Builder(this).setTitle("Tap the widget’s position").setView(crop)
                    .setPositiveButton("Use this crop",(d,w)->{try{crop.store();loadPreview();notice("Wallpaper crop ready");}catch(IOException e){notice("Could not save crop");}})
                    .setNegativeButton("Cancel",null).show();
            }else if(request==3){
                File test=new File(getCacheDir(),draft+".candidate");
                try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(test)){
                    byte[] buffer=new byte[8192];int n,total=0;
                    while((n=in.read(buffer))!=-1){total+=n;if(total>16*1024*1024)throw new IOException();out.write(buffer,0,n);}
                }
                Typeface.createFromFile(test);
                java.nio.file.Files.move(test.toPath(),temporaryFont.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                notice("Font ready");
            }
        }catch(Exception e){notice("Could not open that file");}
    }
    class Crop extends View {
        Bitmap source;RectF image=new RectF(),box=new RectF();Paint pen=new Paint(3);float cx=.5f,cy=.5f;
        Crop(Bitmap bitmap){super(Setup.this);source=bitmap;}
        @Override protected void onMeasure(int w,int h){setMeasuredDimension(MeasureSpec.getSize(w),Math.min(dp(340),getResources().getDisplayMetrics().heightPixels/2));}
        void place(){
            float scale=Math.min((float)getWidth()/source.getWidth(),(float)getHeight()/source.getHeight());
            float w=source.getWidth()*scale,h=source.getHeight()*scale;
            image.set((getWidth()-w)/2,(getHeight()-h)/2,(getWidth()+w)/2,(getHeight()+h)/2);
            Bundle opts=AppWidgetManager.getInstance(Setup.this).getAppWidgetOptions(id);
            float widgetWidth=Math.max(100,opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,196));
            float widgetHeight=Math.max(100,opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,210));
            float cw=w*Math.min(.95f,widgetWidth/getResources().getConfiguration().screenWidthDp);
            float ch=Math.min(h,cw*widgetHeight/widgetWidth);
            float x=image.left+Math.max(0,Math.min(w-cw,cx*w-cw/2)), y=image.top+Math.max(0,Math.min(h-ch,cy*h-ch/2));
            box.set(x,y,x+cw,y+ch);
        }
        @Override protected void onDraw(Canvas c){
            place();pen.setStyle(Paint.Style.FILL);pen.setColor(-1);c.drawBitmap(source,null,image,pen);
            pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(dp(3));c.drawRoundRect(box,dp(8),dp(8),pen);
        }
        @Override public boolean onTouchEvent(MotionEvent e){if(image.width()>0){cx=(e.getX()-image.left)/image.width();cy=(e.getY()-image.top)/image.height();invalidate();}return true;}
        void store() throws IOException {
            place();float scale=source.getWidth()/image.width();
            Rect src=new Rect(Math.max(0,(int)((box.left-image.left)*scale)),Math.max(0,(int)((box.top-image.top)*scale)),
                Math.min(source.getWidth(),Math.round((box.right-image.left)*scale)),Math.min(source.getHeight(),Math.round((box.bottom-image.top)*scale)));
            Bitmap crop=Bitmap.createBitmap(source,src.left,src.top,Math.max(1,src.width()),Math.max(1,src.height()));
            try(OutputStream out=new FileOutputStream(temporaryWall)){crop.compress(Bitmap.CompressFormat.PNG,100,out);}
        }
    }
    void commit(){
        try{
            if(temporaryFont.isFile())java.nio.file.Files.copy(temporaryFont.toPath(),Widget.file(this,id,"font").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            if(temporaryWall.isFile())java.nio.file.Files.copy(temporaryWall.toPath(),Widget.file(this,id,"crop").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            int strength=blur.getProgress(),ink=Color.WHITE;
            File cache=Widget.file(this,id,"blurred");
            if(strength>0 && previewCrop!=null){
                Bitmap bg=Frost.blur(previewCrop,strength);
                android.util.AtomicFile output=new android.util.AtomicFile(cache);
                FileOutputStream stream=output.startWrite();
                try{
                    if(!bg.compress(Bitmap.CompressFormat.PNG,100,stream))throw new IOException();
                    output.finishWrite(stream);
                }catch(IOException|RuntimeException e){output.failWrite(stream);throw e;}
                int average=Bitmap.createScaledBitmap(bg,1,1,true).getPixel(0,0);
                ink=Color.luminance(average)>.20f?Widget.INK:Color.WHITE;
            }else cache.delete();
            prefs.edit().putInt("blur",strength).putInt("textColor",ink).putStringSet("calendars",selection()).apply();
            Widget.render(this,id);
            setResult(RESULT_OK,new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id));finish();
        }catch(Exception e){notice("Could not save widget. Please try again.");}
    }
    @Override public void onDestroy(){if(isFinishing()&&temporaryFont!=null){temporaryFont.delete();temporaryWall.delete();new File(getCacheDir(),draft+".candidate").delete();}super.onDestroy();}
}
