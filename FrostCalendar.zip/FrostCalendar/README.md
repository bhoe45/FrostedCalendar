# Frost Calendar
A 3×3 Android home-screen widget designed for Pixel Launcher. It shows the current week (Monday first) and up to three appointments from today's selected Google calendars. When the day is busy it favors remaining events. The date header opens today, each weekday opens that date, each event opens its Google Calendar detail page, and + starts event creation. Google Calendar controls which calendar view it displays for a date.

## Build and install
Use JDK 17, Gradle 8.9 and Android SDK Platform 35. Run `gradle assembleDebug` from the directory containing build.gradle. Install the APK from build/outputs/apk/debug on the phone. Alternatively push the extracted project, including .github, to a GitHub repo with Actions enabled and download FrostCalendar-APK from its build run.

## Add to Pixel Launcher
1. Install Google Calendar and enable sync for the calendars you want on the phone.
2. Long-press an empty area on the home screen, choose Widgets, and drag Frost Calendar to a 3×3 space.
3. Grant calendar read access and check the calendars for this widget. This filter only changes the widget. Android handles account sync.
4. Pick the wallpaper image (or a clean wallpaper screenshot matching your screen crop) and tap where the widget will sit. The widget blurs and tints that crop locally. Repeat after changing the wallpaper or moving the widget. Without an image it uses a pale background.
5. For exact Product Sans, choose your own TTF or OTF. Without it the widget requests the device's Google Sans family with a system fallback.
6. Tap Save widget. To edit, long-press the widget and use the launcher's configuration control.

Event times follow the phone's 12/24-hour preference. Calendar data and appearance settings stay on the device. Android schedules periodic refreshes and the widget also listens for provider and date changes.
