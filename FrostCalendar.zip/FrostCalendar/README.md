# Frost Calendar
A resizable Pixel Launcher widget, initially three columns wide and two rows tall. The fixed date strip starts with today and shows the next six days. It rolls forward each local day. Selecting a future day returns to today two minutes after the last day tap. The timer uses a non-waking alarm, so Android may deliver it on waking if the phone is asleep. Swipe vertically through the selected day's full agenda from the selected Google calendars. Each weekday switches the widget agenda in place, each event opens its Google Calendar detail page. Event locations appear beside the time when provided. Google Calendar controls which calendar view it displays for a date.

## Build and install
Use JDK 17, Gradle 8.9 and Android SDK Platform 35. Run `gradle assembleDebug` from the directory containing build.gradle. Install the APK from build/outputs/apk/debug on the phone. Alternatively push the extracted project, including .github, to a GitHub repo with Actions enabled and download FrostCalendar-APK from its build run.

## Add to Pixel Launcher
1. Install Google Calendar and enable sync for the calendars you want on the phone.
2. Long-press an empty area on the home screen, choose Widgets, and drag Frost Calendar to a space three columns wide and two rows tall.
3. Grant calendar read access and check the calendars for this widget. This filter only changes the widget. Android handles account sync.
4. For automatic positioning, place and resize the widget, open configuration, and tap **Show alignment markers**. When the calendar disappears and four colored markers appear, take a screenshot. Tap between the markers, select **Import marker screenshot**, choose that screenshot, adjust blur and save. The widget extracts only its area. Repeat after moving or resizing. Alternatively pick the wallpaper image (or a clean wallpaper screenshot matching your screen crop) and tap where the widget will sit. The slider controls blur strength. At 0% the background is transparent. Above 0% it uses an untinted, blurred wallpaper crop. Select the wallpaper once after upgrading from 1.0, which saved only a tinted image. Reposition the crop after moving or resizing the widget.
5. For exact Product Sans, choose your own TTF or OTF. Without it the widget requests the device's Google Sans family with a system fallback.
6. Tap Save widget. To resize, long-press the widget and drag its handles. To edit, long-press the widget and use the launcher's configuration control.

Event times follow the phone's 12/24-hour preference. Calendar data and appearance settings stay on the device. Android schedules periodic refreshes and the widget also listens for provider and date changes.
